import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScanQrPage extends StatefulWidget {
  @override
  _ScanQrPageState createState() => _ScanQrPageState();
}

class _ScanQrPageState extends State<ScanQrPage> {
  final MobileScannerController controller = MobileScannerController();
  bool processed = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Scan Borrow QR")),
      body: MobileScanner(
        controller: controller,
        onDetect: (capture) async {
          if (processed) return;
          processed = true;

          final raw = capture.barcodes.first.rawValue;
          if (raw == null) {
            _showMessage("无法读取 QR");
            return;
          }

          await _processQR(context, raw);
        },
      ),
    );
  }

  Future<void> _processQR(BuildContext context, String raw) async {
    try {
      final data = jsonDecode(raw);

      final requestId = data['requestId'];
      final itemId = data['itemId'];
      final requesterId = data['requesterId'];
      final ownerId = data['ownerId'];
      final appointmentMs = data['appointmentTime'];

      final currentUid = FirebaseAuth.instance.currentUser!.uid;

      // ✔ Only owner can scan
      if (currentUid != ownerId) {
        _showMessage("❌ 只有 Owner 可以确认借出");
        return;
      }

      // ✔ Check request exists
      final reqRef = FirebaseFirestore.instance
          .collection('borrowRequests')
          .doc(requestId);
      final snap = await reqRef.get();

      if (!snap.exists) {
        _showMessage("❌ 请求不存在");
        return;
      }

      final req = snap.data()!;

      // ✔ Must be approved
      if (req['status'] != 'approved') {
        _showMessage("⚠️ 请求未批准或已处理");
        return;
      }

      // (Optional) Check appointment time
      final apptTime = DateTime.fromMillisecondsSinceEpoch(appointmentMs);
      final now = DateTime.now();
      if ((now.difference(apptTime).inHours).abs() > 24) {
        _showMessage("⚠️ 当前时间与预约时间差超过 24 小时");
      }

      // 🔥 Update borrowRequests → borrowed
      await reqRef.update({
        'status': 'borrowed',
        'borrowedAt': FieldValue.serverTimestamp(),
      });

      // 🔥 Update item status → Borrowed
      final itemRef =
          FirebaseFirestore.instance.collection('items').doc(itemId);
      await itemRef.update({
        'status': 'Borrowed',
        'borrowerId': requesterId,
      });

      _showMessage("✅ 借出成功确认！");
    } catch (e) {
      _showMessage("❌ 解析失败：$e");
    }
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    Navigator.pop(context);
  }
}
