// lib/borrow_qr_page.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:qr_flutter/qr_flutter.dart'; // 使用新版 QrImageView

class BorrowQrPage extends StatefulWidget {
  final String requestId;
  const BorrowQrPage({super.key, required this.requestId});

  @override
  State<BorrowQrPage> createState() => _BorrowQrPageState();
}

class _BorrowQrPageState extends State<BorrowQrPage> {
  bool loading = true;
  Map<String, dynamic>? requestData;

  @override
  void initState() {
    super.initState();
    _loadRequest();
  }

  Future<void> _loadRequest() async {
    final doc = await FirebaseFirestore.instance
        .collection('borrowRequests')
        .doc(widget.requestId)
        .get();

    requestData = doc.data();
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Scaffold(
        appBar: AppBar(title: const Text("Borrow QR")),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (requestData == null) {
      return Scaffold(
        appBar: AppBar(title: const Text("Borrow QR")),
        body: const Center(child: Text("Request not found")),
      );
    }

    final status = requestData!['status'];
    final appointment = requestData!['appointment'];

    // ❗ 必须是 Owner 已批准 + 有预约，才能显示 QR
    if (status != 'approved' || appointment == null) {
      return Scaffold(
        appBar: AppBar(title: const Text("Borrow QR")),
        body: const Center(
          child: Text(
            "⚠️ 暂无法生成 QR\n请等待 Owner 批准并设置预约时间地点",
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16),
          ),
        ),
      );
    }

    // 🔥 生成 QR payload
    final payload = jsonEncode({
      'requestId': widget.requestId,
      'itemId': requestData!['itemId'],
      'requesterId': requestData!['requesterId'],
      'ownerId': requestData!['ownerId'],
      'appointmentTime':
          (appointment['dateTime'] as Timestamp).toDate().millisecondsSinceEpoch,
      'location': appointment['location'],
      'issuedAt': DateTime.now().millisecondsSinceEpoch,
    });

    final appointmentTime =
        (appointment['dateTime'] as Timestamp).toDate().toLocal();

    return Scaffold(
      appBar: AppBar(title: const Text("Borrow QR")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "📦 出示 QR 码给 Owner 扫描以确认借出",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),

              const SizedBox(height: 24),

              // 🔥 使用新版 QrImageView
              QrImageView(
                data: payload,
                version: QrVersions.auto,
                size: 260,
                backgroundColor: Colors.white,
              ),

              const SizedBox(height: 20),

              Text(
                "预约时间：$appointmentTime",
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),

              Text(
                "地点：${appointment['location']}",
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),

              const SizedBox(height: 30),

              ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.check),
                label: const Text("完成"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
