import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'scan_qr_page.dart';

class BorrowRequestsPage extends StatefulWidget {
  const BorrowRequestsPage({super.key});

  @override
  State<BorrowRequestsPage> createState() => _BorrowRequestsPageState();
}

class _BorrowRequestsPageState extends State<BorrowRequestsPage>
    with SingleTickerProviderStateMixin {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  // -------------------------
  // Approve Request Dialog
  // -------------------------
  Future<void> _approveRequest({
    required String requestId,
    required String itemId,
    required String requesterId,
  }) async {
    final TextEditingController locationCtrl = TextEditingController();
    DateTime? selectedDateTime;

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Set Appointment"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ElevatedButton(
              onPressed: () async {
                final date = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2100),
                  initialDate: DateTime.now(),
                );
                if (date == null) return;

                final time = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.now(),
                );
                if (time == null) return;

                selectedDateTime = DateTime(
                  date.year,
                  date.month,
                  date.day,
                  time.hour,
                  time.minute,
                );
              },
              child: const Text("Choose Appointment Time"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: locationCtrl,
              decoration: const InputDecoration(
                labelText: "Location",
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            child: const Text("Cancel"),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            child: const Text("Approve"),
            onPressed: () async {
              if (selectedDateTime == null || locationCtrl.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Please select time and location")),
                );
                return;
              }

              // 1. Update request
              await _firestore.collection('borrowRequests').doc(requestId).update({
                'status': 'approved',
                'appointment': {
                  'dateTime': selectedDateTime,
                  'location': locationCtrl.text.trim(),
                },
                'updatedAt': FieldValue.serverTimestamp(),
              });

              // 2. Update item record
              await _firestore.collection('items').doc(itemId).update({
                'status': 'borrowed',
                'borrowerId': requesterId,
              });

              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Request approved!")),
              );
            },
          ),
        ],
      ),
    );
  }

  // -------------------------
  // Firestore Query Builder
  // -------------------------
  Stream<QuerySnapshot> _requestStreamForStatus(String status) {
    final uid = _auth.currentUser!.uid;

    return _firestore
        .collection("borrowRequests")
        .where(
          Filter.or(
            Filter("ownerId", isEqualTo: uid),
            Filter("requesterId", isEqualTo: uid),
          ),
        )
        .where("status", isEqualTo: status)
        .orderBy("requestedAt", descending: true)
        .snapshots();
  }

  // -------------------------
  // Reusable Request Card UI
  // -------------------------
  Widget _buildRequestCard(Map<String, dynamic> data, String docId) {
    final currentUid = _auth.currentUser!.uid;
    final bool isOwner = data["ownerId"] == currentUid;
    final String status = data["status"];
    final String itemId = data["itemId"];
    final String requesterId = data["requesterId"];

    Color statusColor = Colors.orange;
    if (status == "approved") statusColor = Colors.green;
    if (status == "rejected") statusColor = Colors.red;
    if (status == "borrowed") statusColor = Colors.blue;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: ListTile(
        title: Text("Item: $itemId"),
        subtitle: Text("Requester: $requesterId\nStatus: $status"),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                status.toUpperCase(),
                style: TextStyle(color: statusColor),
              ),
            ),
            const SizedBox(width: 8),

            // Show approve / reject only for owner
            if (status == "pending" && isOwner) ...[
              IconButton(
                icon: const Icon(Icons.check_circle, color: Colors.green),
                onPressed: () {
                  _approveRequest(
                    requestId: docId,
                    itemId: itemId,
                    requesterId: requesterId,
                  );
                },
              ),
              IconButton(
                icon: const Icon(Icons.cancel, color: Colors.red),
                onPressed: () {
                  _firestore.collection("borrowRequests").doc(docId).update({
                    'status': 'rejected',
                    'updatedAt': FieldValue.serverTimestamp(),
                  });
                },
              ),
            ]
          ],
        ),
      ),
    );
  }

  // -------------------------
  // Build Tab Content
  // -------------------------
  Widget _buildTab(String status) {
    return StreamBuilder(
      stream: _requestStreamForStatus(status),
      builder: (context, snapshot) {
       if (snapshot.hasError) {
    print("🔥 FIRESTORE ERROR: ${snapshot.error}");
  }


        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return const Center(child: Text("No requests here."));
        }

        return ListView(
          children: docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return _buildRequestCard(data, doc.id);
          }).toList(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Borrow Requests"),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.blue,
          unselectedLabelColor: Colors.grey,
          tabs: const [
            Tab(text: "Pending"),
            Tab(text: "Approved"),
            Tab(text: "Borrowed"),
            Tab(text: "Rejected"),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ScanQrPage()),
              );
            },
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildTab("pending"),
          _buildTab("approved"),
          _buildTab("borrowed"),
          _buildTab("rejected"),
        ],
      ),
    );
  }
}
