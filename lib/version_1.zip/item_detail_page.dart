import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'report_page.dart';
import 'borrow_qr_page.dart';

class ItemDetailPage extends StatefulWidget {
  final String itemId;
  const ItemDetailPage({super.key, required this.itemId});

  @override
  State<ItemDetailPage> createState() => _ItemDetailPageState();
}

class _ItemDetailPageState extends State<ItemDetailPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Map<String, dynamic>? itemData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadItem();
  }

  Future<void> _loadItem() async {
    try {
      final snap =
          await _firestore.collection('items').doc(widget.itemId).get();

      if (snap.exists) {
        setState(() {
          itemData = snap.data();
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  Future<void> sendBorrowRequest() async {
    final uid = _auth.currentUser!.uid;

    await _firestore.collection('borrowRequests').add({
      'itemId': widget.itemId,
      'requesterId': uid,
      'ownerId': itemData!['ownerId'],
      'status': 'pending',
      'requestedAt': FieldValue.serverTimestamp(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Request Sent! Please wait for approval.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    print("🔥 ItemDetailPage BUILD");
    print("🔥 itemId: ${widget.itemId}");
    print("🔥 itemData loaded: $itemData");
    print("🔥 currentUser: ${_auth.currentUser?.uid}");

    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (itemData == null) {
      return const Scaffold(
        body: Center(child: Text("Item not found")),
      );
    }

    final String currentUid = _auth.currentUser!.uid;
    final bool isOwner = itemData!['ownerId'] == currentUid;

    return Scaffold(
      appBar: AppBar(
        title: Text(itemData!['title'] ?? "Item Details"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.network(
                itemData!['imageUrl'],
                height: 220,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),

            const SizedBox(height: 20),

            Text(
              itemData!['title'],
              style: const TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 10),
            Text(itemData!['description']),
            const SizedBox(height: 20),

            Text(
              "Owner: ${itemData!['ownerName']}",
              style: const TextStyle(color: Colors.grey),
            ),

            const SizedBox(height: 30),

            //-----------------------------------------------
            // 🔥 Borrower buttons (FutureBuilder FIXED)
            //-----------------------------------------------
            Expanded(
              child: FutureBuilder<QuerySnapshot>(
                future: _firestore
                    .collection('borrowRequests')
                    .where('itemId', isEqualTo: widget.itemId)
                    .where('requesterId', isEqualTo: currentUid)
                    .orderBy('requestedAt', descending: true)
                    .limit(1)
                    .get(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState ==
                      ConnectionState.waiting) {
                    return const Center(
                        child: CircularProgressIndicator());
                  }

                  if (!snapshot.hasData ||
                      snapshot.data!.docs.isEmpty) {
                    return _borrowButton();
                  }

                  final req = snapshot.data!.docs.first;
                  final data = req.data() as Map<String, dynamic>;
                  final status = data['status'];
                  final appointment = data['appointment'];

                  print("----- Request Debug -----");
                  print("Status: $status");
                  print("Appointment: $appointment");
                  print("------------------------");

                  if (status == 'pending') {
                    return const Center(
                      child: Text(
                        "⏳ Waiting for owner approval...",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    );
                  }

                  if (status == 'rejected') {
                    return const Center(
                      child: Text(
                        "❌ Request rejected",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    );
                  }

                  if (status == 'approved' && appointment == null) {
                    return const Center(
                      child: Text(
                        "✔ Approved\nWaiting for owner appointment",
                        textAlign: TextAlign.center,
                      ),
                    );
                  }

                  if (status == 'approved' && appointment != null) {
                    return Center(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => BorrowQrPage(
                                requestId: req.id,
                              ),
                            ),
                          );
                        },
                        icon: const Icon(Icons.qr_code),
                        label: const Text("Show QR Code"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 40,
                            vertical: 14,
                          ),
                        ),
                      ),
                    );
                  }

                  return _borrowButton();
                },
              ),
            ),

            //-----------------------------------------------
            // Owner-only Report Button
            //-----------------------------------------------
            if (itemData!['status'] == "Borrowed" && isOwner)
              Center(
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ReportPage(
                          borrowerId: itemData!['borrowerId'],
                          itemId: widget.itemId,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.report),
                  label: const Text("Report Borrower"),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _borrowButton() {
    return Center(
      child: ElevatedButton.icon(
        onPressed: sendBorrowRequest,
        icon: const Icon(Icons.handshake),
        label: const Text("Borrow Item"),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue,
          padding: const EdgeInsets.symmetric(
              horizontal: 40, vertical: 14),
        ),
      ),
    );
  }
}
