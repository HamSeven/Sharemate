// lib/register_page.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'verify_email_page.dart';
import 'widgets/auth_card.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool _isLoading = false;
  String? errorMessage;

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> register() async {
    final name = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text;

    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      setState(() => errorMessage = 'Please fill all fields');
      return;
    }

    if (!email.endsWith('@sc.edu.my')) {
      setState(() => errorMessage = 'Only @sc.edu.my emails are allowed');
      return;
    }

    setState(() {
      errorMessage = null;
      _isLoading = true;
    });

    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = cred.user;
      if (user == null) {
        setState(() => errorMessage = 'Registration failed.');
        return;
      }

      // Save display name locally in Auth (profile). Firestore profile created in VerifyEmailPage.
      try {
        await user.updateDisplayName(name);
      } catch (_) {}

      // send verification email then go to VerifyEmailPage
      await user.sendEmailVerification();
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => VerifyEmailPage(user: user)));
    } on FirebaseAuthException catch (e) {
      setState(() => errorMessage = e.message ?? e.code);
    } catch (e) {
      setState(() => errorMessage = e.toString());
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      body: AuthCard(
        headerIcon: const Icon(Icons.person_add, color: Colors.blue, size: 40),
        title: 'Create an account',
        subtitle: 'Sign up with your sc.edu.my email',
        children: [
          TextField(
            controller: nameController,
            decoration: InputDecoration(
              labelText: 'Full name',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecoration(
              labelText: 'Email',
              hintText: 'you@sc.edu.my',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: passwordController,
            obscureText: true,
            decoration: InputDecoration(
              labelText: 'Password',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
            ),
          ),
          const SizedBox(height: 14),
          if (errorMessage != null) ...[
            Text(errorMessage!, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 10),
          ],
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isLoading ? null : register,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: _isLoading
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('Create account', style: TextStyle(fontSize: 16)),
            ),
          ),
        ],
        bottomActions: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Already have an account?', style: TextStyle(color: Colors.grey.shade600)),
              TextButton(onPressed: () => Navigator.pushReplacementNamed(context, '/login'), child: const Text('Sign in')),
            ],
          ),
        ],
      ),
    );
  }
}
