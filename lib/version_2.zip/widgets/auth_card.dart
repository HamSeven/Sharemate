// lib/widgets/auth_card.dart
import 'package:flutter/material.dart';

/// Reusable Auth Card used by Login / Register / Verify pages.
/// Usage: wrap your form widgets inside the `children` parameter.
/// Provide optional headerIcon, title, subtitle, and bottomActions.
class AuthCard extends StatelessWidget {
  final Widget? headerIcon;
  final String title;
  final String? subtitle;
  final List<Widget> children;
  final List<Widget>? bottomActions;
  final EdgeInsetsGeometry padding;
  final double maxWidth;
  final Color? backgroundColor;
  final BorderRadiusGeometry borderRadius;
  final List<BoxShadow>? boxShadow;

  const AuthCard({
    super.key,
    this.headerIcon,
    required this.title,
    this.subtitle,
    required this.children,
    this.bottomActions,
    this.padding = const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
    this.maxWidth = 460,
    this.backgroundColor,
    this.borderRadius = const BorderRadius.all(Radius.circular(16)),
    this.boxShadow,
  });

  @override
  Widget build(BuildContext context) {
    final bg = backgroundColor ?? Colors.white;
    final shadow = boxShadow ??
        [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ];

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Container(
          padding: padding,
          constraints: BoxConstraints(maxWidth: maxWidth),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: borderRadius,
            boxShadow: shadow,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (headerIcon != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: headerIcon,
                ),
              if (headerIcon != null) const SizedBox(height: 12),

              // Title
              Text(
                title,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),

              if (subtitle != null) const SizedBox(height: 6),

              if (subtitle != null)
                Text(
                  subtitle!,
                  style: TextStyle(color: Colors.grey.shade600),
                  textAlign: TextAlign.center,
                ),

              const SizedBox(height: 14),

              // The user-provided children (form fields, error text, buttons)
              ...children,

              if (bottomActions != null) const SizedBox(height: 12),

              if (bottomActions != null)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: bottomActions!,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

