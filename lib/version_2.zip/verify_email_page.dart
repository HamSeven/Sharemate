import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'theme/design_tokens.dart';

class VerifyEmailPage extends StatelessWidget {
  final User user;

  const VerifyEmailPage({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text("Verify your email"),
        centerTitle: false,
        titleSpacing: 16,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Icon(
                Icons.mark_email_unread_outlined,
                size: 72,
                color: AppColors.primary,
              ),

              const SizedBox(height: 24),

              Text(
                "Verify your email",
                style: AppText.titleLarge,
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 12),

              Text(
                "A verification link has been sent to:",
                style: AppText.bodyMedium,
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 4),

              Text(
                user.email ?? '',
                style: AppText.labelMedium.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 32),

              // 🔵 Resend button (full width)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.send),
                  label: const Text("Resend verification email"),
                  onPressed: () async {
                    await user.sendEmailVerification();
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Verification email resent"),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 12),

              // 🔵 I have verified (same width)
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () async {
                    await user.reload();
                    if (FirebaseAuth.instance.currentUser!.emailVerified) {
                      Navigator.of(context).pushReplacementNamed('/home');
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Email not verified yet"),
                        ),
                      );
                    }
                  },
                  child: const Text("I have verified"),
                ),
              ),

              const SizedBox(height: 20),

              TextButton(
                onPressed: () async {
                  await FirebaseAuth.instance.signOut();
                },
                child: const Text("Cancel and logout"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
