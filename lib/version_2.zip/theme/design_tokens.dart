// lib/theme/design_tokens.dart
import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFFF5F7FA);
  static const Color card = Colors.white;

  static const Color primary = Color(0xFF2563EB); // blue-600
  static const Color primarySoft = Color(0xFFDBEAFE);

  static const Color success = Color(0xFF16A34A);
  static const Color info = Color(0xFF2563EB);
  static const Color danger = Color(0xFFDC2626);

  static const Color textPrimary = Color(0xFF0F172A);
  static const Color textSecondary = Color(0xFF64748B);
}

class AppRadius {
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;

  static const BorderRadius card = BorderRadius.all(Radius.circular(16));
}

class AppShadows {
  static final List<BoxShadow> soft = [
    BoxShadow(
      color: Colors.black.withOpacity(0.05),
      blurRadius: 20,
      offset: const Offset(0, 10),
    ),
  ];
}

class AppText {
  // 🔹 页面 / 卡片大标题
  static const TextStyle titleLarge = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
  );

  // 🔹 卡片副标题
  static const TextStyle titleMedium = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  // 🔹 正文
  static const TextStyle bodyLarge = TextStyle(
    fontSize: 14,
    color: AppColors.textPrimary,
  );

  // 🔹 辅助说明文字
  static const TextStyle bodyMedium = TextStyle(
    fontSize: 13,
    color: AppColors.textSecondary,
  );

  // 🔹 标签 / 状态 pill
  static const TextStyle labelMedium = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w600,
  );
}
