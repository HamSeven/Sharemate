import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'theme/design_tokens.dart';
import 'borrow_qr_page.dart';
import 'scan_qr_page.dart';

class BorrowRequestDetailPage extends StatelessWidget {
  final String requestId;

  const BorrowRequestDetailPage({
    super.key,
    required this.requestId,
  });

  @override
  Widget build(BuildContext context) {
    final currentUid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text("Borrow Request Details"),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('borrowRequests')
            .doc(requestId)
            .snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snap.data!.exists) {
            return const Center(child: Text("Request not found"));
          }

          final data = snap.data!.data() as Map<String, dynamic>;
          final status = data['status'];
          final requesterId = data['requesterId'];
          final ownerId = data['ownerId'];
          final itemId = data['itemId'];
          final appointment = data['appointment'];

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _itemSection(itemId),
                const SizedBox(height: 16),

                if (appointment != null &&
                    (status == 'approved' ||
                        status == 'borrowed' ||
                        status == 'return_pending'))
                  _appointmentCard(appointment),

                const SizedBox(height: 16),

                _actionSection(
                  context: context,
                  status: status,
                  currentUid: currentUid,
                  requesterId: requesterId,
                  ownerId: ownerId,
                  itemId: itemId,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // =========================================================
  // Item info
  // =========================================================
  Widget _itemSection(String itemId) {
    return FutureBuilder<DocumentSnapshot>(
      future:
          FirebaseFirestore.instance.collection('items').doc(itemId).get(),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const SizedBox(
            height: 200,
            child: Center(child: CircularProgressIndicator()),
          );
        }

        if (!snap.data!.exists) {
          return const Text("Item not found");
        }

        final item = snap.data!.data() as Map<String, dynamic>;

        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: AppRadius.card,
            boxShadow: AppShadows.soft,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (item['imageUrl'] != null && item['imageUrl'] != '')
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    item['imageUrl'],
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                )
              else
                Container(
                  height: 200,
                  color: Colors.grey[200],
                  child: const Icon(Icons.inventory_2, size: 60),
                ),
              const SizedBox(height: 12),
              Text(item['title'] ?? 'Unnamed Item',
                  style: AppText.titleLarge),
              const SizedBox(height: 6),
              Text(item['description'] ?? '',
                  style: AppText.bodyMedium),
            ],
          ),
        );
      },
    );
  }

  // =========================================================
  // Appointment
  // =========================================================
  Widget _appointmentCard(Map<String, dynamic> appointment) {
    final dt =
        (appointment['dateTime'] as Timestamp).toDate().toLocal();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.primarySoft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Appointment", style: AppText.titleMedium),
          const SizedBox(height: 6),
          Text("📅 $dt", style: AppText.bodyMedium),
          Text("📍 ${appointment['location']}",
              style: AppText.bodyMedium),
        ],
      ),
    );
  }

  // =========================================================
  // Action buttons by role & status
  // =========================================================
  Widget _actionSection({
    required BuildContext context,
    required String status,
    required String currentUid,
    required String requesterId,
    required String ownerId,
    required String itemId,
  }) {
    // ------------------------
    // APPROVED
    // ------------------------
    if (status == 'approved') {
      // Borrower → show QR
      if (currentUid == requesterId) {
        return ElevatedButton.icon(
          icon: const Icon(Icons.qr_code),
          label: const Text("Show QR Code"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => BorrowQrPage(requestId: requestId),
              ),
            );
          },
        );
      }

      // Owner → scan QR
      if (currentUid == ownerId) {
        return ElevatedButton.icon(
          icon: const Icon(Icons.qr_code_scanner),
          label: const Text("Scan Borrower QR"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ScanQrPage(
                
              ),
              )
            );
          },
        );
      }
    }

    // ------------------------
    // BORROWED → Borrower can request return
    // ------------------------
    if (status == 'borrowed' && currentUid == requesterId) {
      return ElevatedButton.icon(
        icon: const Icon(Icons.undo),
        label: const Text("Request Return"),
        onPressed: () async {
  final firestore = FirebaseFirestore.instance;

  // 1️⃣ 读 item（拿 ownerId）
  final itemSnap =
      await firestore.collection('items').doc(itemId).get();

  if (!itemSnap.exists) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Item not found")),
    );
    return;
  }

  final itemOwnerId = itemSnap['ownerId'];

  // 2️⃣ 创建 return request
  await firestore.collection('returnRequests').add({
    'borrowRequestId': requestId,
    'itemId': itemId,

    'borrowerId': requesterId,
    'ownerId': itemOwnerId,

    'status': 'pending',
    'requestedAt': FieldValue.serverTimestamp(),
  });

  // 3️⃣ borrow request → return_pending
  await firestore
      .collection('borrowRequests')
      .doc(requestId)
      .update({
    'status': 'return_pending',
  });

  // 🔑 同步 item 状态 → return_pending
  await firestore.collection('items').doc(itemId).update({
    'status': 'return_pending',
  });

  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text("Return request sent")),
  );
}


      );
    }

    // ------------------------
    // RETURN PENDING
    // ------------------------
    if (status == 'return_pending') {
      return const Text(
        "⏳ Waiting for owner to approve return",
        style: AppText.bodyMedium,
      );
    }

    // ------------------------
    // REJECTED
    // ------------------------
    if (status == 'rejected') {
      return Text(
        "❌ Request rejected",
        style: AppText.bodyMedium.copyWith(color: AppColors.danger),
      );
    }

    return const SizedBox.shrink();
  }
}
