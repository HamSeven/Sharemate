import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'theme/design_tokens.dart';

class BorrowQrPage extends StatelessWidget {
  final String requestId;
  const BorrowQrPage({super.key, required this.requestId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text("Borrow Confirmation"),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance
            .collection('borrowRequests')
            .doc(requestId)
            .get(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snap.data!.data() as Map<String, dynamic>;
          final appointment = data['appointment'];

          if (data['status'] != 'approved' || appointment == null) {
            return const Center(
              child: Text(
                "QR not available",
                style: AppText.bodyMedium,
              ),
            );
          }

          final payload = jsonEncode({
            'requestId': requestId,
            'itemId': data['itemId'],
            'requesterId': data['requesterId'],
            'ownerId': data['ownerId'],
            'appointmentTime': (appointment['dateTime'] as Timestamp)
                .toDate()
                .millisecondsSinceEpoch,
            'location': appointment['location'],
          });

          final dateTime =
              (appointment['dateTime'] as Timestamp).toDate().toLocal();

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // =====================
                // Header
                // =====================
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: AppRadius.card,
                    boxShadow: AppShadows.soft,
                  ),
                  child: Column(
                    children: const [
                      Icon(Icons.qr_code_2, size: 40),
                      SizedBox(height: 8),
                      Text(
                        "Show this QR to the owner",
                        style: AppText.titleMedium,
                      ),
                      SizedBox(height: 4),
                      Text(
                        "This QR is required to confirm borrowing",
                        style: AppText.bodySmall,
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // =====================
                // QR Card
                // =====================
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: AppRadius.card,
                    boxShadow: AppShadows.soft,
                  ),
                  child: QrImageView(
                    data: payload,
                    size: 240,
                    backgroundColor: Colors.white,
                  ),
                ),

                const SizedBox(height: 20),

                // =====================
                // Appointment Info
                // =====================
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: AppRadius.card,
                    boxShadow: AppShadows.soft,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Appointment Details",
                          style: AppText.titleMedium),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.schedule, size: 18),
                          const SizedBox(width: 6),
                          Text(dateTime.toString(),
                              style: AppText.bodyMedium),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          const Icon(Icons.location_on, size: 18),
                          const SizedBox(width: 6),
                          Text(appointment['location'],
                              style: AppText.bodyMedium),
                        ],
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                // =====================
                // Done Button
                // =====================
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.check),
                    label: const Text("I have shown this QR"),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
